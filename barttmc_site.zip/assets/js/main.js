// Small interactive helpers
document.getElementById('year').textContent = new Date().getFullYear();
// Lightbox for gallery (naive, no libs)
(function(){
  const items = document.querySelectorAll('.gallery-item');
  if(!items.length) return;
  const lb = document.createElement('div');
  lb.className = 'lightbox';
  lb.style.cssText = 'position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,0.85);z-index:999;padding:20px';
  const img = document.createElement('img');
  img.style.maxWidth='95%'; img.style.maxHeight='95%'; img.style.borderRadius='8px';
  lb.appendChild(img);
  document.body.appendChild(lb);
  items.forEach(a=>{
    a.addEventListener('click', e=>{
      e.preventDefault();
      img.src = a.href;
      lb.style.display='flex';
    });
  });
  lb.addEventListener('click', ()=> lb.style.display='none');
})();
// Smooth scroll for internal links
document.querySelectorAll('a[href^="#"]').forEach(a=>{
  a.addEventListener('click', e=>{
    const href = a.getAttribute('href');
    if(href === '#') return;
    const el = document.querySelector(href);
    if(el){ e.preventDefault(); el.scrollIntoView({behavior:'smooth'}); }
  });
});
