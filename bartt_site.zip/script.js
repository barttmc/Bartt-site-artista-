// script.js
document.addEventListener('DOMContentLoaded', function(){
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  const menuToggle = document.getElementById('menuToggle');
  const mainNav = document.getElementById('mainNav');
  if(menuToggle && mainNav){
    menuToggle.addEventListener('click', ()=> {
      if(mainNav.style.display === 'flex') mainNav.style.display = 'none';
      else mainNav.style.display = 'flex';
    });
  }
});
